#include <Arduino.h>      // Einbinden der Datei Arduino-Bibliothek

class Led {               // Beginn der Klassendefinition
    int  pinLed;          // LED-Pin (Attritbute der Klasse)
    bool stateLed;        // Zustand der LED 

  public:                 // alle Methoden (oder Attribute) nach public sind öffentlich
    Led(int pPin) {       // Konstruktor (ohne void, int, etc.)
      pinLed   = pPin;
      stateLed = false;
      pinMode(pinLed, OUTPUT);
    }
    void toggle() {       // Die Methoden einer Klassen können auf die Attribute zugreifen      
      stateLed = !stateLed; 
      digitalWrite(pinLed, stateLed);
    }
};                        // Eine Klassendefinition endet immer mit einem Semikolon
